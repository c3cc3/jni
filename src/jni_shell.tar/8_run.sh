java TestEnQ
