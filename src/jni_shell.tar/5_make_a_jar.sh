set -x
jar cvf FileQueueJNI.jar com
