echo  "Make a header from java source"
set -x
javac -h . FileQueueJNI.java
