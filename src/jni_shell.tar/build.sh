set -x
./1_make_a_header.sh
./2_make_a_object.sh
./3_make_a_shared_object.sh
./4_make_a_java_class.sh
./5_make_a_jar.sh
./6_make_test.sh

