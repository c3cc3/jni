set -x
javac -d . FileQueueJNI.java
